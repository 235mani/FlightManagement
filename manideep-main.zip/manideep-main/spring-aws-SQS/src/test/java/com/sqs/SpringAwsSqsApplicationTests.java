package com.sqs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAwsSqsApplicationTests {

	@Test
	void contextLoads() {
	}

}
