package com.deploy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAwsDeployApplicationTests {

	@Test
	void contextLoads() {
	}

}
