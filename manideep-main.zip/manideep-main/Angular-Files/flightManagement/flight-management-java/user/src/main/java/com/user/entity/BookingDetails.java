package com.user.entity;

public class BookingDetails {

}
