package com.user.entity;

public class PassengerDetails {

}
